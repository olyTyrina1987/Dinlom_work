package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
 

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

public class MainActivity2 extends AppCompatActivity {


  
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void clickButton333 (View v) throws IOException {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    
    public void clickButton334 (View v) throws IOException {
        EditText et = (EditText)findViewById(R.id.edit_text);
        String EditText1 = et.getText().toString();
        int EditText11 = new Integer(EditText1).intValue();
        
        
         if (EditText11 == 12345)
         {
             Toast.makeText(getApplicationContext(), "Редатор доступен!", Toast.LENGTH_SHORT).show();
             Intent intent = new Intent(this, MainActivity3.class);
             startActivity(intent);
         }
        else 
        {
            Toast.makeText(getApplicationContext(), "Пароль введен неверный!", Toast.LENGTH_SHORT).show();
        }    
    }
    
 
}